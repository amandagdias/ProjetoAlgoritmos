Arquivo zip gerado em: 13/05/2017 14:00:30 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Xadrez - Parte 2