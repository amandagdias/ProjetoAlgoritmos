Arquivo zip gerado em: 21/05/2017 09:54:13 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Transformada de Fourier Aplicada a Áudio