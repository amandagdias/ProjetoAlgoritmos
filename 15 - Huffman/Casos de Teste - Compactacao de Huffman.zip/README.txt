Arquivo zip gerado em: 09/06/2017 00:42:40 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Compactação de Huffman