Arquivo zip gerado em: 14/06/2017 15:20:33 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Optical Character Recognition