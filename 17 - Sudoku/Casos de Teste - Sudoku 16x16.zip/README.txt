Arquivo zip gerado em: 11/06/2017 23:36:17 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Sudoku 16x16