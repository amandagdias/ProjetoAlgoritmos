#include<stdio.h>
#include<stdlib.h>
typedef struct caminhos{
	int index;
	float x;
	float y;
	int nemp;
	struct caminhos* next;
	struct caminhos* prev;	
	
}CAMINHOS;
typedef struct{
	CAMINHOS* cam;
	int num;
	float dist;
}SOLUCAO;
typedef struct pilha{
	int index;
	struct pilha* next;
	
}PILHA;
typedef struct{
	float x;
	float y;
}PONTO;
typedef struct{
	int v;
	int n; 
	int o;
	
}CAMARA;
typedef struct{
	int b;
	int e;
	float d;
}SEGMENTOS;
void Salvar_Solucao(CAMINHOS* head, SOLUCAO* sol_head)
{
	CAMINHOS* p;
	SOLUCAO* q;
	p = (CAMINHOS*) malloc(sizeof(CAMINHOS));
	q = (SOLUCAO*) calloc(1, sizeof(SOLUCAO));
	q->cam = (CAMINHOS*)malloc(sizeof(CAMINHOS));
	p = head;
	while (p)
	{
		printf("%d ", p->index);
		p=p->next;		
	}
	printf("\n");
//	sol_head->cam->index = p->index;
//	sol_head->cam->x = p->x;
//	sol_head->cam->y = p->y;
//	sol_head->cam->next = p->next;
//	sol_head->cam->prev = p->prev;
//	q->cam = sol_head->cam;
//	q->cam = q->cam->next;
//	p=p->next;
//	while (p)
//	{
//		q->cam->index = p->index;
//		q->cam->x = p->x;
//		q->cam->y = p->y;
//		q->cam->next = p->next;
//		q->cam->prev = p->prev;
//		
//		p=p->next;
//		q->cam = q->cam->next;
//		q->num++;
//		
//	}
//	q->dist = 0;	
}
void push(PILHA** head, int index)
{
	PILHA* p;
	p = (PILHA*) malloc(sizeof(PILHA));
	p->index = index;
	p->next = NULL;
	if (*head==NULL)
	{
		*head = p;
		return;
	}
	p->next = *head;
	*head = p;	
}
int pop(PILHA** head)
{
	int value;
	value = (*head)->index;
	*head = (*head)->next;
	return value;	
}
int isCamara(int index, CAMARA* c, int ncamara)
{
	int i;
	for (i=0; i < ncamara; i++)
	{
		if (c[i].v == index)
			return i;
	}
	return -1;
}
int push_children(int index, PILHA** pilha, SEGMENTOS* s, int nseg, int* visitados){
	int i;
	int count;
	for (i =0; i < nseg; i++)	
	{
		if (s[i].b == index)
		{
			if ((s[i].e > 0)&&(visitados[(s[i].e)]==0))
			{
				push(pilha, index);
				count++;
			}
		}
	}
	return count;
}
void Find_Paths(CAMARA* c, PONTO* p, SEGMENTOS* s, SOLUCAO** sol, int ncamara, int nponto, int nseg, int Cs)
{
	CAMINHOS* head, *tail;
	int* visitados;
	int index, cam_index, nsol, saida, nemp;
 	PILHA *pilha;
	visitados = (int*) calloc(nponto, sizeof(int));
	head = (CAMINHOS*) malloc(sizeof(CAMINHOS));
	tail = (CAMINHOS*) malloc(sizeof(CAMINHOS));
	head->index = Cs;	
	head->x = p[Cs].x;
	head->y = p[Cs].y;
	tail = head;
	head->next = tail;
	head->prev = NULL;
	tail->next = NULL;
	tail->prev = head;
	head->nemp = push_children(Cs, &pilha, s, nseg, visitados);
	visitados[Cs] = 1;
	nsol=0;
	CAMINHOS *p_aux;
	p_aux = (CAMINHOS*) malloc(sizeof(CAMINHOS));
	while(pilha!=NULL)
	{
		index = pop(&pilha);
		visitados[index] = 1;
		cam_index = isCamara(index, c, ncamara);
		saida =0;
		if (cam_index!=-1)
		{
			
			if (c[cam_index].o==1)
			{
				//eh saida				
				p_aux->index = index;
				p_aux->x = p[index].x;
				p_aux->y = p[index].y;
				p_aux->nemp = 0;
				p_aux->prev = tail->prev;
				tail->prev->next = p_aux;
				p_aux->next = NULL;				
				tail = p_aux;				
				Salvar_Solucao(head, sol[nsol]);
				nsol++;
				while(tail->nemp <=1)
				{
					visitados[tail->index] = 0;
					tail = tail->prev;					
				}
				tail->nemp--;
				saida = 1;				
			}						
		}
		if (!saida)
		{
			
			nemp = push_children(index, &pilha, s, nseg, visitados);
			if (nemp==0)			
			{
				tail->nemp--;
				while(tail->nemp <=1)
				{
					visitados[tail->index] = 0;
					tail = tail->prev;					
				}
				tail->nemp--;
			}else{
				p_aux->index = index;
				p_aux->x = p[index].x;
				p_aux->y = p[index].y;
				p_aux->nemp = nemp;
				p_aux->prev = tail->prev;
				tail->prev->next = p_aux;
				p_aux->next = NULL;				
				tail = p_aux;		
			}
		}		
	}	
}
int main(){
	PONTO* ponto;
	CAMARA* camara;
	SEGMENTOS* seg;
	SOLUCAO** sol;
	
	int nseg, ncamara, nponto;
	int i, Cs;
	FILE* file;
	
	file = fopen("7.in", "r");
	fscanf(file, "%d", &nponto);
	
	ponto = (PONTO*) malloc(sizeof(PONTO)*nponto);
	for (i=0; i < nponto; i++)
	{
		fscanf(file, "%f %f", &ponto[i].x, &ponto[i].y);		
	}
	fscanf(file, "%d", &ncamara);
	camara = (CAMARA*) malloc(sizeof(CAMARA)*ncamara);
	for (i=0; i < ncamara; i++)
	{
		fscanf(file, "%d %d", &camara[i].v, &camara[i].o);
		camara[i].v--;
	}
	fscanf(file, "%d", &nseg);
	seg = (SEGMENTOS*) malloc(sizeof(SEGMENTOS)*nseg);
	for (i=0; i < nseg; i++)
	{
		fscanf(file, "%d %d", &seg[i].b, &seg[i].e);
		if (seg[i].b > 0)
			seg[i].b--;
		else
			seg[i].b++;			
		if (seg[i].e > 0)
			seg[i].e--;
		else
			seg[i].e++;		
	}	
	fscanf(file, "%d", &Cs);
	
	sol = (SOLUCAO**) malloc(sizeof(SOLUCAO*)*100);
//	printf("%d\n", nponto);
//	for (i=0; i < nponto; i++)
//	{
//		printf("%f %f\n", ponto[i].x, ponto[i].y);		
//	}
//	printf("\n%d\n", ncamara);
//	for (i=0; i < ncamara; i++)
//	{
//		printf("%d %d\n", camara[i].v, camara[i].o);
//		
//	}
//	printf("\n%d\n", nseg);
//	for (i=0; i < nseg; i++)
//	{
//		printf("%d %d\n", seg[i].b, seg[i].e);		
//	}	
	Find_Paths(camara, ponto, seg, sol, ncamara, nponto, nseg, Cs );
}

