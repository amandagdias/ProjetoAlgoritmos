/*
Nome: Amanda Goncalves Dias
NUSP: 10275312
Turma: Projeto de Algoritmos SCC5900
Data Entrega: 04/07/2017
*/
#ifndef _ITEM_H_
#define _ITEM_H_

struct item {
	int chave;
	int valor;
};

typedef struct item ITEM;


#endif
