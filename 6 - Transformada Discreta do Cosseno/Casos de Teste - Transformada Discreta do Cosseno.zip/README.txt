Arquivo zip gerado em: 13/04/2017 17:49:15 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Transformada Discreta do Cosseno