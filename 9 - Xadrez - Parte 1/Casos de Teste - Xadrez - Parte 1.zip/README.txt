Arquivo zip gerado em: 09/05/2017 23:27:27 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Xadrez - Parte 1